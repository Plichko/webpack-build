export default (val) => {
  return JSON.parse(JSON.stringify(val))
}
